package providedCode;

/**
 * interface for function objects that hash data
 */
public interface Hasher {
	public int hash(String str);
}
